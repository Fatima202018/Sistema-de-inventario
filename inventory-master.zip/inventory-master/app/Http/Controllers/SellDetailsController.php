<?php

namespace App\Http\Controllers;

use App\SellDetails;
use Illuminate\Http\Request;

class SellDetailsController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\SellDetails  $sellDetails
     * @return \Illuminate\Http\Response
     */
    public function show(SellDetails $sellDetails)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\SellDetails  $sellDetails
     * @return \Illuminate\Http\Response
     */
    public function edit(SellDetails $sellDetails)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\SellDetails  $sellDetails
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, SellDetails $sellDetails)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\SellDetails  $sellDetails
     * @return \Illuminate\Http\Response
     */
    public function destroy(SellDetails $sellDetails)
    {
        //
    }
}
